# JSPrint
JSPrint, is a python package to bring a JS like way of logging to the console. Made with :heart:.
